import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Offer from './components/Offer';
import Pricing from './components/Pricing';
import Quiz from './components/Quiz';
import Gallery from './components/Gallery';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';
import { LegalModals } from './components/LegalModals';
import { LanguageProvider } from './LanguageContext';

function App() {
  const [imprintOpen, setImprintOpen] = useState(false);
  const [privacyOpen, setPrivacyOpen] = useState(false);

  // Global smooth scrolling handler
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      
      // Check if it's a hash link pointing to the same page
      if (anchor && anchor.hash && anchor.hash.startsWith('#') && anchor.origin === window.location.origin) {
        const element = document.querySelector(anchor.hash);
        if (element) {
          e.preventDefault();
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
          // Manually update the URL hash without jumping
          window.history.pushState(null, '', anchor.hash);
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  const closeLegalModals = () => {
    setImprintOpen(false);
    setPrivacyOpen(false);
  };

  return (
    <LanguageProvider>
      <div className="min-h-screen bg-black text-white selection:bg-turbo-400 selection:text-black">
        <Navbar />
        <Hero />
        <Features />
        <Offer />
        <Pricing />
        <Quiz />
        <Gallery />
        <Testimonials />
        <FAQ />
        <Contact />
        <Footer 
          onOpenImprint={() => setImprintOpen(true)} 
          onOpenPrivacy={() => setPrivacyOpen(true)} 
        />
        <Chatbot />
        <LegalModals 
          imprintOpen={imprintOpen} 
          privacyOpen={privacyOpen} 
          closeAll={closeLegalModals} 
        />
      </div>
    </LanguageProvider>
  );
}

export default App;