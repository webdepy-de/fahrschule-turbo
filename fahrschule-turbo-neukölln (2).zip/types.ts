export interface PricingItem {
  service: string;
  duration: string;
  price: string;
}

export interface GalleryImage {
  url: string;
  alt: string;
}

export interface NavItem {
  label: string;
  href: string;
}