
export const translations = {
  DE: {
    nav: {
      start: 'Start',
      offer: 'Angebot',
      pricing: 'Preise',
      quiz: 'Quiz',
      gallery: 'Galerie',
      faq: 'FAQ',
      contact: 'Kontakt',
      call: 'Anrufen'
    },
    hero: {
      since: 'Seit 1985',
      location: 'Berlin Neukölln',
      headline_prefix: 'FAHRSCHULE',
      headline_suffix: 'TURBO',
      subheadline: 'Dein Führerschein in Rekordzeit. Wir begleiten dich sicher und schnell ans Ziel.',
      languages: 'Deutsch, Englisch, Türkisch & Arabisch.',
      btn_offer: 'Zum Angebot',
      btn_contact: 'Kontakt aufnehmen'
    },
    features: {
      lang_title: '4 Sprachen',
      lang_desc: 'Theorie- und Fahrstunden auf Deutsch, Englisch, Türkisch & Arabisch.',
      fleet_title: 'Moderne Flotte',
      fleet_desc: 'Lerne auf aktuellen Fahrzeugen mit modernster Technik.',
      central_title: 'Zentral',
      central_desc: 'Donaustraße 101, 12043 Berlin Neukölln. Perfekt erreichbar.',
      hours_title: 'Öffnungszeiten',
      hours_desc: 'Mo-Fr 10:00-18:00 | Sa 10:00-16:00'
    },
    offer: {
      badge: 'BEGRENZTES ANGEBOT',
      title_prefix: 'EASY',
      title_highlight: 'START',
      description: 'Ausbildung zum unschlagbaren Paketpreis, alles was du für den Start brauchst in einem Paket.',
      features: [
        "Antrag beim Bürgeramt",
        "1x 60 Minuten Übungsfahrt",
        "Erste Hilfe Kurs",
        "Sehtest",
        "Theorie",
        "LernApp",
        "Express Theorie"
      ],
      price_label: 'Komplettpreis',
      price_value: '50€',
      instead_of: 'Statt 299€',
      btn_signup: 'Jetzt Anmelden',
      disclaimer: '* Angebot gilt für Neuanmeldungen.'
    },
    pricing: {
      title: 'PREISLISTE',
      subtitle: 'Transparent und fair. Keine versteckten Kosten.',
      col_service: 'Leistung',
      col_duration: 'Dauer',
      col_price: 'Preis',
      items: [
        { service: "Übungsstunde", duration: "45 Min.", price: "56,25 €" },
        { service: "Übungsstunde", duration: "80 Min.", price: "100,00 €" },
        { service: "Autobahnfahrt", duration: "180 Min.", price: "290,00 €" },
        { service: "Überlandfahrt", duration: "225 Min.", price: "300,00 €" },
        { service: "Nachtfahrt", duration: "135 Min.", price: "180,00 €" },
        { service: "Vorstellung zur Prüfung", duration: "Praxis", price: "180,00 €" },
      ]
    },
    quiz: {
      title: 'FIT FÜR DIE STRAßE?',
      subtitle: 'Teste dein Wissen in unserem Turbo-Quiz!',
      question_label: 'FRAGE',
      points_label: 'Punkte',
      finished_title: 'Quiz Beendet!',
      finished_desc: 'Du hast {score} von {total} Fragen richtig beantwortet.',
      perfect: 'Perfekt! Du bist bereit für die Anmeldung!',
      good: 'Nicht schlecht! Wir bringen dir den Rest bei.',
      btn_retry: 'Nochmal versuchen',
      questions: [
        {
          question: "Ab welchem Alter darfst du mit 'Begleitetem Fahren' (BF17) starten?",
          options: ["16 Jahre", "16 ½ Jahre", "17 Jahre", "18 Jahre"],
          explanation: "Du kannst dich bereits mit 16 ½ Jahren anmelden und mit der Ausbildung beginnen!"
        },
        {
          question: "Wie lange ist der Erste-Hilfe-Kurs gültig?",
          options: ["1 Jahr", "2 Jahre", "5 Jahre", "Unbegrenzt"],
          explanation: "Die Bescheinigung über den Erste-Hilfe-Kurs gilt grundsätzlich unbegrenzt."
        },
        {
          question: "Wie viele Sonderfahrten sind für Klasse B Pflicht?",
          options: ["10 Fahrten", "12 Fahrten", "5 Fahrten", "Keine Pflicht"],
          explanation: "Pflicht sind 5 Überland-, 4 Autobahn- und 3 Nachtfahrten. Insgesamt 12 Sonderfahrten."
        }
      ]
    },
    gallery: {
      title: 'ERFOLGSSTORIES',
      subtitle: 'Unsere Fahrschüler haben es geschafft. Du bist der Nächste!',
      followers: 'Follower',
      posts: 'Beiträge',
      passed_badge: 'Bestanden!',
      insta_btn_small: 'Folge uns auf Instagram',
      insta_btn_link: 'Mehr auf Instagram sehen'
    },
    testimonials: {
      title: 'DAS SAGEN UNSERE SCHÜLER',
      subtitle: 'Echte Meinungen, echte Erfolge. Werde auch du Teil der Turbo-Familie.',
      reviews: [
        { name: "Murat K.", text: "Beste Fahrschule in Neukölln! Habe meinen Führerschein in 3 Wochen gemacht. Super nettes Team." },
        { name: "Sarah L.", text: "Die Fahrlehrer sind sehr geduldig und erklären alles super verständlich. Kann ich nur empfehlen!" },
        { name: "Ahmad O.", text: "Sehr professionell und hilfsbereit, besonders bei der Theorie. Danke für alles!" },
        { name: "Lisa M.", text: "Top Vorbereitung auf die Prüfung. Hatte erst Angst, aber der Fahrlehrer hat mir die Angst genommen." }
      ]
    },
    faq: {
      title: 'HÄUFIGE FRAGEN',
      subtitle: 'Alles was du wissen musst.',
      items: [
        {
          q: "Wie lange dauert die Führerscheinausbildung?",
          a: "Das hängt von deinem Lernfortschritt ab. Mit unserem 'Easy Start Paket' und Express-Theorie kannst du die Theorie in 7 Tagen durchziehen."
        },
        {
          q: "Kann ich mich online anmelden?",
          a: "Ja, nutze einfach unser Kontaktformular weiter unten. Wir bereiten alles vor."
        },
        {
          q: "Welche Sprachen bietet ihr an?",
          a: "Wir unterrichten Theorie und Praxis auf Deutsch, Englisch, Türkisch und Arabisch."
        },
        {
          q: "Was brauche ich für den Antrag beim Bürgeramt?",
          a: "Biometrisches Passbild, Sehtest, Erste-Hilfe-Kurs Nachweis und Ausweis."
        },
        {
          q: "Wie viel kostet der Führerschein insgesamt?",
          a: "Die Gesamtkosten variieren je nach Fahrstunden. Grundbetrag aktuell 50€."
        }
      ]
    },
    contact: {
      title: 'KONTAKT',
      address_title: 'Adresse',
      phone_title: 'Telefon & Handy',
      email_title: 'Email',
      form_title: 'Anmeldung & Anfrage',
      label_name: 'Name',
      placeholder_name: 'Dein vollständiger Name',
      label_phone: 'Telefon',
      placeholder_phone: 'Deine Handynummer',
      label_interest: 'Interesse an',
      option_auto: 'Autoführerschein (Klasse B)',
      option_moto: 'Motorradführerschein (Klasse A)',
      option_citizen: 'Bürgerservice / Antragshilfe',
      option_other: 'Sonstige Anfrage',
      label_msg: 'Nachricht',
      placeholder_msg: 'Wie können wir dir helfen?',
      btn_submit: 'Absenden'
    },
    footer: {
      rights: 'Alle Rechte vorbehalten.',
      imprint: 'Impressum',
      privacy: 'Datenschutz'
    },
    chat: {
      title: 'Turbo Assistent',
      placeholder: 'Stell uns eine Frage...',
      welcome: 'Hallo! Ich bin der KI-Assistent der Fahrschule Turbo. Wie kann ich dir helfen?',
      typing: 'Tippt...',
      send: 'Senden'
    }
  },
  EN: {
    nav: {
      start: 'Home',
      offer: 'Offer',
      pricing: 'Prices',
      quiz: 'Quiz',
      gallery: 'Gallery',
      faq: 'FAQ',
      contact: 'Contact',
      call: 'Call Now'
    },
    hero: {
      since: 'Since 1985',
      location: 'Berlin Neukölln',
      headline_prefix: 'DRIVING SCHOOL',
      headline_suffix: 'TURBO',
      subheadline: 'Get your license in record time. We guide you safely and quickly to your goal.',
      languages: 'German, English, Turkish & Arabic.',
      btn_offer: 'See Offer',
      btn_contact: 'Contact Us'
    },
    features: {
      lang_title: '4 Languages',
      lang_desc: 'Theory and driving lessons in German, English, Turkish & Arabic.',
      fleet_title: 'Modern Fleet',
      fleet_desc: 'Learn on current vehicles with the latest technology.',
      central_title: 'Central',
      central_desc: 'Donaustraße 101, 12043 Berlin Neukölln. Perfectly accessible.',
      hours_title: 'Opening Hours',
      hours_desc: 'Mon-Fri 10:00-18:00 | Sat 10:00-16:00'
    },
    offer: {
      badge: 'LIMITED TIME OFFER',
      title_prefix: 'EASY',
      title_highlight: 'START',
      description: 'Training for an unbeatable package price, everything you need to get started in one package.',
      features: [
        "Application at Citizens Office",
        "1x 60 Minutes Practice Drive",
        "First Aid Course",
        "Eye Test",
        "Theory Lessons",
        "Learning App",
        "Express Theory"
      ],
      price_label: 'Complete Price',
      price_value: '50€',
      instead_of: 'Instead of 299€',
      btn_signup: 'Sign Up Now',
      disclaimer: '* Offer valid for new registrations.'
    },
    pricing: {
      title: 'PRICE LIST',
      subtitle: 'Transparent and fair. No hidden costs.',
      col_service: 'Service',
      col_duration: 'Duration',
      col_price: 'Price',
      items: [
        { service: "Practice Lesson", duration: "45 Min.", price: "56,25 €" },
        { service: "Practice Lesson", duration: "80 Min.", price: "100,00 €" },
        { service: "Autobahn Drive", duration: "180 Min.", price: "290,00 €" },
        { service: "Cross-country Drive", duration: "225 Min.", price: "300,00 €" },
        { service: "Night Drive", duration: "135 Min.", price: "180,00 €" },
        { service: "Practical Exam", duration: "Practical", price: "180,00 €" },
      ]
    },
    quiz: {
      title: 'FIT FOR THE ROAD?',
      subtitle: 'Test your knowledge in our Turbo Quiz!',
      question_label: 'QUESTION',
      points_label: 'Points',
      finished_title: 'Quiz Finished!',
      finished_desc: 'You answered {score} out of {total} questions correctly.',
      perfect: 'Perfect! You are ready to sign up!',
      good: 'Not bad! We will teach you the rest.',
      btn_retry: 'Try Again',
      questions: [
        {
          question: "At what age can you start with 'Accompanied Driving' (BF17)?",
          options: ["16 Years", "16 ½ Years", "17 Years", "18 Years"],
          explanation: "You can register and start training as early as 16 ½ years old!"
        },
        {
          question: "How long is the First Aid Course valid?",
          options: ["1 Year", "2 Years", "5 Years", "Unlimited"],
          explanation: "The First Aid Course certificate is basically valid indefinitely."
        },
        {
          question: "How many special drives are mandatory for Class B?",
          options: ["10 Drives", "12 Drives", "5 Drives", "No obligation"],
          explanation: "Mandatory are 5 cross-country, 4 autobahn, and 3 night drives. Total 12."
        }
      ]
    },
    gallery: {
      title: 'SUCCESS STORIES',
      subtitle: 'Our students made it. You are next!',
      followers: 'Followers',
      posts: 'Posts',
      passed_badge: 'Passed!',
      insta_btn_small: 'Follow us on Instagram',
      insta_btn_link: 'See more on Instagram'
    },
    testimonials: {
      title: 'WHAT OUR STUDENTS SAY',
      subtitle: 'Real opinions, real success. Become part of the Turbo family.',
      reviews: [
        { name: "Murat K.", text: "Best driving school in Neukölln! Got my license in 3 weeks. Super nice team." },
        { name: "Sarah L.", text: "The instructors are very patient and explain everything clearly. Highly recommended!" },
        { name: "Ahmad O.", text: "Very professional and helpful, especially with theory. Thanks for everything!" },
        { name: "Lisa M.", text: "Top preparation for the exam. Was scared at first, but the instructor took away my fear." }
      ]
    },
    faq: {
      title: 'FAQ',
      subtitle: 'Everything you need to know.',
      items: [
        {
          q: "How long does driver training take?",
          a: "It depends on your progress. With our 'Easy Start Package' you can finish theory in 7 days."
        },
        {
          q: "Can I register online?",
          a: "Yes, just use our contact form below."
        },
        {
          q: "What languages do you offer?",
          a: "We teach theory and practice in German, English, Turkish, and Arabic."
        },
        {
          q: "What do I need for the application?",
          a: "Biometric photo, eye test, first aid course proof, and ID."
        },
        {
          q: "How much does the license cost in total?",
          a: "Total costs vary. Our base fee is currently 50€."
        }
      ]
    },
    contact: {
      title: 'CONTACT',
      address_title: 'Address',
      phone_title: 'Phone & Mobile',
      email_title: 'Email',
      form_title: 'Registration & Inquiry',
      label_name: 'Name',
      placeholder_name: 'Your full name',
      label_phone: 'Phone',
      placeholder_phone: 'Your mobile number',
      label_interest: 'Interest in',
      option_auto: 'Car License (Class B)',
      option_moto: 'Motorcycle License (Class A)',
      option_citizen: 'Citizen Service / Application Help',
      option_other: 'Other Inquiry',
      label_msg: 'Message',
      placeholder_msg: 'How can we help you?',
      btn_submit: 'Send'
    },
    footer: {
      rights: 'All rights reserved.',
      imprint: 'Imprint',
      privacy: 'Privacy'
    },
    chat: {
      title: 'Turbo Assistant',
      placeholder: 'Ask us a question...',
      welcome: 'Hello! I am the AI assistant of Fahrschule Turbo. How can I help you?',
      typing: 'Typing...',
      send: 'Send'
    }
  },
  TR: {
    nav: {
      start: 'Başlangıç',
      offer: 'Teklif',
      pricing: 'Fiyatlar',
      quiz: 'Quiz',
      gallery: 'Galeri',
      faq: 'SSS',
      contact: 'İletişim',
      call: 'Ara'
    },
    hero: {
      since: '1985\'ten beri',
      location: 'Berlin Neukölln',
      headline_prefix: 'SÜRÜCÜ KURSU',
      headline_suffix: 'TURBO',
      subheadline: 'Rekor sürede ehliyetin senin olsun. Seni hedefine güvenli ve hızlı bir şekilde ulaştırıyoruz.',
      languages: 'Almanca, İngilizce, Türkçe ve Arapça.',
      btn_offer: 'Teklifi Gör',
      btn_contact: 'İletişime Geç'
    },
    features: {
      lang_title: '4 Dil',
      lang_desc: 'Almanca, İngilizce, Türkçe ve Arapça teori ve direksiyon dersleri.',
      fleet_title: 'Modern Araçlar',
      fleet_desc: 'En son teknolojiye sahip güncel araçlarla öğren.',
      central_title: 'Merkezi',
      central_desc: 'Donaustraße 101, 12043 Berlin Neukölln. Mükemmel ulaşım.',
      hours_title: 'Çalışma Saatleri',
      hours_desc: 'Pzt-Cum 10:00-18:00 | Cmt 10:00-16:00'
    },
    offer: {
      badge: 'SINIRLI SÜRELİ TEKLİF',
      title_prefix: 'KOLAY',
      title_highlight: 'BAŞLANGIÇ',
      description: 'Rakipsiz paket fiyatına eğitim, başlangıç için ihtiyacın olan her şey tek pakette.',
      features: [
        "Vatandaşlık Bürosu Başvurusu",
        "1x 60 Dakika Alıştırma Sürüşü",
        "İlk Yardım Kursu",
        "Göz Testi",
        "Teori Dersleri",
        "Öğrenme Uygulaması",
        "Ekspres Teori"
      ],
      price_label: 'Komple Fiyat',
      price_value: '50€',
      instead_of: '299€ yerine',
      btn_signup: 'Şimdi Kaydol',
      disclaimer: '* Teklif yeni kayıtlar için geçerlidir.'
    },
    pricing: {
      title: 'FİYAT LİSTESİ',
      subtitle: 'Şeffaf ve adil. Gizli maliyet yok.',
      col_service: 'Hizmet',
      col_duration: 'Süre',
      col_price: 'Fiyat',
      items: [
        { service: "Alıştırma Dersi", duration: "45 Dk.", price: "56,25 €" },
        { service: "Alıştırma Dersi", duration: "80 Dk.", price: "100,00 €" },
        { service: "Otoban Sürüşü", duration: "180 Dk.", price: "290,00 €" },
        { service: "Şehirlerarası Sürüş", duration: "225 Dk.", price: "300,00 €" },
        { service: "Gece Sürüşü", duration: "135 Dk.", price: "180,00 €" },
        { service: "Pratik Sınav", duration: "Pratik", price: "180,00 €" },
      ]
    },
    quiz: {
      title: 'YOLLARA HAZIR MISIN?',
      subtitle: 'Bilgini Turbo Quiz\'imizde test et!',
      question_label: 'SORU',
      points_label: 'Puan',
      finished_title: 'Quiz Bitti!',
      finished_desc: '{total} sorudan {score} tanesini doğru cevapladın.',
      perfect: 'Mükemmel! Kaydolmaya hazırsın!',
      good: 'Fena değil! Gerisini biz öğretiriz.',
      btn_retry: 'Tekrar Dene',
      questions: [
        {
          question: "'Refakatçi Sürüşü' (BF17) ile kaç yaşında başlayabilirsin?",
          options: ["16 Yaş", "16 ½ Yaş", "17 Yaş", "18 Yaş"],
          explanation: "16 ½ yaşında kayıt olabilir ve eğitime başlayabilirsin!"
        },
        {
          question: "İlk Yardım Kursu ne kadar süre geçerlidir?",
          options: ["1 Yıl", "2 Yıl", "5 Yıl", "Sınırsız"],
          explanation: "İlk Yardım Kursu sertifikası temel olarak süresiz geçerlidir."
        },
        {
          question: "B Sınıfı için kaç özel sürüş zorunludur?",
          options: ["10 Sürüş", "12 Sürüş", "5 Sürüş", "Zorunlu değil"],
          explanation: "5 şehirlerarası, 4 otoban ve 3 gece sürüşü zorunludur. Toplam 12."
        }
      ]
    },
    gallery: {
      title: 'BAŞARI HİKAYELERİ',
      subtitle: 'Öğrencilerimiz başardı. Sıradaki sensin!',
      followers: 'Takipçi',
      posts: 'Gönderi',
      passed_badge: 'Geçti!',
      insta_btn_small: 'Bizi Instagram\'da takip et',
      insta_btn_link: 'Daha fazlasını Instagram\'da gör'
    },
    testimonials: {
      title: 'ÖĞRENCİLERİMİZ NE DİYOR',
      subtitle: 'Gerçek görüşler, gerçek başarılar. Sen de Turbo ailesine katıl.',
      reviews: [
        { name: "Murat K.", text: "Neukölln'deki en iyi sürücü kursu! 3 haftada ehliyetimi aldım. Çok iyi ekip." },
        { name: "Sarah L.", text: "Eğitmenler çok sabırlı ve her şeyi harika açıklıyorlar. Kesinlikle tavsiye ederim!" },
        { name: "Ahmad O.", text: "Çok profesyonel ve yardımsever, özellikle teoride. Her şey için teşekkürler!" },
        { name: "Lisa M.", text: "Sınav için harika hazırlık. Başta korkuyordum ama eğitmen korkumu aldı." }
      ]
    },
    faq: {
      title: 'SIKÇA SORULAN SORULAR',
      subtitle: 'Bilmen gereken her şey.',
      items: [
        {
          q: "Ehliyet eğitimi ne kadar sürer?",
          a: "İlerlemene bağlıdır. 'Kolay Başlangıç Paketi' ve Ekspres Teori ile teoriyi 7 günde bitirebilirsin."
        },
        {
          q: "Online kayıt olabilir miyim?",
          a: "Evet, sadece aşağıdaki iletişim formunu kullan. Her şeyi hazırlıyoruz."
        },
        {
          q: "Hangi dilleri sunuyorsunuz?",
          a: "Almanca, İngilizce, Türkçe ve Arapça teori ve pratik eğitimi veriyoruz."
        },
        {
          q: "Başvuru için neye ihtiyacım var?",
          a: "Biyometrik fotoğraf, göz testi, ilk yardım kursu belgesi ve kimlik."
        },
        {
          q: "Ehliyet toplamda ne kadar tutar?",
          a: "Toplam maliyet ders sayısına göre değişir. Taban ücretimiz şu an 50€."
        }
      ]
    },
    contact: {
      title: 'İLETİŞİM',
      address_title: 'Adres',
      phone_title: 'Telefon & Cep',
      email_title: 'E-posta',
      form_title: 'Kayıt & Talep',
      label_name: 'İsim',
      placeholder_name: 'Adın Soyadın',
      label_phone: 'Telefon',
      placeholder_phone: 'Cep numarası',
      label_interest: 'İlgilendiğim',
      option_auto: 'Araba Ehliyeti (B Sınıfı)',
      option_moto: 'Motosiklet Ehliyeti (A Sınıfı)',
      option_citizen: 'Vatandaşlık Hizmeti / Başvuru Yardımı',
      option_other: 'Diğer',
      label_msg: 'Mesaj',
      placeholder_msg: 'Nasıl yardımcı olabiliriz?',
      btn_submit: 'Gönder'
    },
    footer: {
      rights: 'Tüm hakları saklıdır.',
      imprint: 'Künye',
      privacy: 'Gizlilik'
    },
    chat: {
      title: 'Turbo Asistan',
      placeholder: 'Bir soru sor...',
      welcome: 'Merhaba! Ben Sürücü Kursu Turbo\'nun yapay zeka asistanıyım. Sana nasıl yardımcı olabilirim?',
      typing: 'Yazıyor...',
      send: 'Gönder'
    }
  },
  AR: {
    nav: {
      start: 'البداية',
      offer: 'العرض',
      pricing: 'الأسعار',
      quiz: 'اختبار',
      gallery: 'المعرض',
      faq: 'الأسئلة',
      contact: 'اتصل بنا',
      call: 'اتصل الآن'
    },
    hero: {
      since: 'منذ عام 1985',
      location: 'برلين نويكولن',
      headline_prefix: 'مدرسة القيادة',
      headline_suffix: 'توربو',
      subheadline: 'احصل على رخصة القيادة في وقت قياسي. نوجهك بأمان وسرعة نحو هدفك.',
      languages: 'الألمانية والإنجليزية والتركية والعربية.',
      btn_offer: 'شاهد العرض',
      btn_contact: 'تواصل معنا'
    },
    features: {
      lang_title: '4 لغات',
      lang_desc: 'دروس نظرية وعملية باللغات الألمانية والإنجليزية والتركية والعربية.',
      fleet_title: 'أسطول حديث',
      fleet_desc: 'تعلم على أحدث المركبات بأحدث التقنيات.',
      central_title: 'موقع مركزي',
      central_desc: 'شارع الدانوب 101، 12043 برلين نويكولن. سهولة الوصول.',
      hours_title: 'ساعات العمل',
      hours_desc: 'الاثنين-الجمعة 10:00-18:00 | السبت 10:00-16:00'
    },
    offer: {
      badge: 'عرض لفترة محدودة',
      title_prefix: 'بداية',
      title_highlight: 'سهلة',
      description: 'تدريب بسعر حزمة لا يهزم، كل ما تحتاجه للبدء في حزمة واحدة.',
      features: [
        "تقديم الطلب في مكتب المواطنين",
        "1x 60 دقيقة قيادة تجريبية",
        "دورة الإسعافات الأولية",
        "فحص النظر",
        "الدروس النظرية",
        "تطبيق التعلم",
        "نظري سريع"
      ],
      price_label: 'السعر الكامل',
      price_value: '50€',
      instead_of: 'بدلاً من 299€',
      btn_signup: 'سجل الآن',
      disclaimer: '* العرض ساري للتسجيلات الجديدة.'
    },
    pricing: {
      title: 'قائمة الأسعار',
      subtitle: 'شفافة وعادلة. لا تكاليف مخفية.',
      col_service: 'الخدمة',
      col_duration: 'المدة',
      col_price: 'السعر',
      items: [
        { service: "درس تدريبي", duration: "45 دقيقة", price: "56,25 €" },
        { service: "درس تدريبي", duration: "80 دقيقة", price: "100,00 €" },
        { service: "قيادة على الطريق السريع", duration: "180 دقيقة", price: "290,00 €" },
        { service: "قيادة عبر البلاد", duration: "225 دقيقة", price: "300,00 €" },
        { service: "قيادة ليلية", duration: "135 دقيقة", price: "180,00 €" },
        { service: "الامتحان العملي", duration: "عملي", price: "180,00 €" },
      ]
    },
    quiz: {
      title: 'جاهز للطريق؟',
      subtitle: 'اختبر معلوماتك في اختبارنا السريع!',
      question_label: 'سؤال',
      points_label: 'النقاط',
      finished_title: 'انتهى الاختبار!',
      finished_desc: 'لقد أجبت بشكل صحيح على {score} من {total} أسئلة.',
      perfect: 'ممتاز! أنت جاهز للتسجيل!',
      good: 'ليس سيئاً! سنعلمك الباقي.',
      btn_retry: 'حاول مرة أخرى',
      questions: [
        {
          question: "في أي عمر يمكنك البدء بـ 'القيادة المصحوبة' (BF17)؟",
          options: ["16 سنة", "16 ½ سنة", "17 سنة", "18 سنة"],
          explanation: "يمكنك التسجيل وبدء التدريب في عمر 16 ½ سنة!"
        },
        {
          question: "كم مدة صلاحية دورة الإسعافات الأولية؟",
          options: ["سنة واحدة", "سنتان", "5 سنوات", "غير محدودة"],
          explanation: "شهادة دورة الإسعافات الأولية صالحة بشكل عام إلى أجل غير مسمى."
        },
        {
          question: "كم عدد الرحلات الخاصة الإلزامية للفئة B؟",
          options: ["10 رحلات", "12 رحلة", "5 رحلات", "لا يوجد التزام"],
          explanation: "الإلزامي هو 5 رحلات عبر البلاد، 4 على الطريق السريع، و 3 رحلات ليلية. المجموع 12."
        }
      ]
    },
    gallery: {
      title: 'قصص نجاح',
      subtitle: 'طلابنا نجحوا. أنت التالي!',
      followers: 'متابع',
      posts: 'منشور',
      passed_badge: 'ناجح!',
      insta_btn_small: 'تابعنا على انستغرام',
      insta_btn_link: 'شاهد المزيد على انستغرام'
    },
    testimonials: {
      title: 'ماذا يقول طلابنا',
      subtitle: 'آراء حقيقية، نجاحات حقيقية. كن جزءاً من عائلة توربو.',
      reviews: [
        { name: "Murat K.", text: "أفضل مدرسة قيادة في نويكولن! حصلت على الرخصة في 3 أسابيع. فريق رائع جداً." },
        { name: "Sarah L.", text: "المدربون صبورون جداً ويشرحون كل شيء بوضوح. أنصح بها بشدة!" },
        { name: "Ahmad O.", text: "محترفون جداً ومتعاونون، خاصة في النظري. شكراً على كل شيء!" },
        { name: "Lisa M.", text: "تحضير ممتاز للامتحان. كنت خائفة في البداية، لكن المدرب أزال خوفي." }
      ]
    },
    faq: {
      title: 'الأسئلة الشائعة',
      subtitle: 'كل ما تحتاج لمعرفته.',
      items: [
        {
          q: "كم يستغرق التدريب على القيادة؟",
          a: "يعتمد ذلك على تقدمك. مع حزمة 'البداية السهلة' والنظري السريع، يمكنك إنهاء النظري في 7 أيام."
        },
        {
          q: "هل يمكنني التسجيل عبر الإنترنت؟",
          a: "نعم، فقط استخدم نموذج الاتصال أدناه. نحن نجهز كل شيء."
        },
        {
          q: "ما اللغات التي تقدمونها؟",
          a: "نحن نعلم النظري والعملي باللغات الألمانية والإنجليزية والتركية والعربية."
        },
        {
          q: "ماذا أحتاج للتقديم؟",
          a: "صورة بيومترية، فحص نظر، إثبات دورة إسعافات أولية، والهوية."
        },
        {
          q: "كم تكلفة الرخصة الإجمالية؟",
          a: "تختلف التكلفة الإجمالية حسب عدد الدروس. رسومنا الأساسية حالياً 50€."
        }
      ]
    },
    contact: {
      title: 'اتصل بنا',
      address_title: 'العنوان',
      phone_title: 'الهاتف والجوال',
      email_title: 'البريد الإلكتروني',
      form_title: 'التسجيل والاستفسار',
      label_name: 'الاسم',
      placeholder_name: 'اسمك الكامل',
      label_phone: 'الهاتف',
      placeholder_phone: 'رقم جوالك',
      label_interest: 'مهتم بـ',
      option_auto: 'رخصة سيارة (فئة B)',
      option_moto: 'رخصة دراجة نارية (فئة A)',
      option_citizen: 'خدمة المواطنين / مساعدة في الطلب',
      option_other: 'استفسار آخر',
      label_msg: 'الرسالة',
      placeholder_msg: 'كيف يمكننا مساعدتك؟',
      btn_submit: 'إرسال'
    },
    footer: {
      rights: 'جميع الحقوق محفوظة.',
      imprint: 'بيانات الشركة',
      privacy: 'الخصوصية'
    },
    chat: {
      title: 'المساعد الذكي',
      placeholder: 'اسألنا سؤالاً...',
      welcome: 'أهلاً! أنا المساعد الذكي لمدرسة تعليم القيادة توربو. كيف يمكنني مساعدتك؟',
      typing: 'يكتب...',
      send: 'إرسال'
    }
  }
};
