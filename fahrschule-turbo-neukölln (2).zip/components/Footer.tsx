import React from 'react';
import { useLanguage } from '../LanguageContext';

interface FooterProps {
  onOpenImprint: () => void;
  onOpenPrivacy: () => void;
}

const Footer: React.FC<FooterProps> = ({ onOpenImprint, onOpenPrivacy }) => {
  const { t } = useLanguage();

  return (
    <footer className="bg-zinc-950 border-t border-white/5 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-6">
          <img src="https://i.imgur.com/25kXdLL.png" alt="Fahrschule Turbo Logo" className="h-16 w-auto object-contain opacity-80 hover:opacity-100 transition-opacity" />
        </div>
        <p className="text-gray-500 text-sm mb-4">
          © {new Date().getFullYear()} Fahrschule Turbo Berlin Neukölln. {t.footer.rights}
        </p>
        <div className="flex justify-center gap-6 text-sm text-gray-600">
           <button onClick={onOpenImprint} className="hover:text-gray-400 transition-colors">{t.footer.imprint}</button>
           <button onClick={onOpenPrivacy} className="hover:text-gray-400 transition-colors">{t.footer.privacy}</button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;