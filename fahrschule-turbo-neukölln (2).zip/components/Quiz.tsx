import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, RefreshCw } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

const Quiz: React.FC = () => {
  const { t } = useLanguage();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  // Correct answers indices for the questions (Indices must match questions in translations.ts)
  const correctAnswers = [1, 3, 1]; 

  // Reset quiz when language changes to avoid index out of bounds or mixed languages
  useEffect(() => {
    restartQuiz();
  }, [t]);

  const handleAnswerClick = (optionIndex: number) => {
    if (selectedOption !== null) return; // Prevent double clicking

    setSelectedOption(optionIndex);
    const correct = optionIndex === correctAnswers[currentQuestion];
    setIsCorrect(correct);

    if (correct) {
      setScore(score + 1);
    }

    setTimeout(() => {
      const nextQuestion = currentQuestion + 1;
      if (nextQuestion < t.quiz.questions.length) {
        setCurrentQuestion(nextQuestion);
        setSelectedOption(null);
        setIsCorrect(null);
      } else {
        setShowScore(true);
      }
    }, 2500);
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedOption(null);
    setIsCorrect(null);
  };

  const questions = t.quiz.questions;

  return (
    <section id="quiz" className="py-24 bg-zinc-950 border-t border-white/5">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-black text-white mb-4">{t.quiz.title}</h2>
          <p className="text-gray-400">{t.quiz.subtitle}</p>
        </div>

        <div className="glass-card rounded-3xl p-8 border border-turbo-400/20 relative overflow-hidden min-h-[400px] flex flex-col justify-center">
          {/* Background decoration */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-turbo-400/5 rounded-full blur-3xl -z-10"></div>

          <AnimatePresence mode='wait'>
            {showScore ? (
              <motion.div 
                key="score"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="text-center space-y-6"
              >
                <div className="text-6xl mb-4">🏆</div>
                <h3 className="text-3xl font-bold text-white">{t.quiz.finished_title}</h3>
                <p className="text-xl text-gray-300">
                  {t.quiz.finished_desc.replace('{score}', score.toString()).replace('{total}', questions.length.toString())}
                </p>
                
                <div className="pt-4">
                  {score === questions.length ? (
                    <p className="text-green-400 font-medium">{t.quiz.perfect}</p>
                  ) : (
                    <p className="text-yellow-400 font-medium">{t.quiz.good}</p>
                  )}
                </div>

                <button 
                  onClick={restartQuiz}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-white font-bold transition-all mt-4"
                >
                  <RefreshCw size={20} />
                  {t.quiz.btn_retry}
                </button>
              </motion.div>
            ) : (
              <motion.div 
                key={currentQuestion}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                className="w-full"
              >
                <div className="flex justify-between items-center mb-6">
                  <span className="text-turbo-400 font-bold text-sm tracking-widest">{t.quiz.question_label} {currentQuestion + 1}/{questions.length}</span>
                  <span className="text-gray-500 text-sm">{t.quiz.points_label}: {score}</span>
                </div>
                
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-8 leading-snug">
                  {questions[currentQuestion].question}
                </h3>

                <div className="grid gap-3">
                  {questions[currentQuestion].options.map((option, index) => {
                    let buttonClass = "w-full p-4 text-left rounded-xl border border-white/10 transition-all font-medium text-lg ";
                    
                    if (selectedOption === null) {
                      buttonClass += "bg-white/5 text-gray-300 hover:bg-white/10 hover:border-turbo-400";
                    } else {
                      if (index === correctAnswers[currentQuestion]) {
                        buttonClass += "bg-green-500/20 border-green-500 text-green-400";
                      } else if (index === selectedOption) {
                        buttonClass += "bg-red-500/20 border-red-500 text-red-400";
                      } else {
                        buttonClass += "bg-black/20 text-gray-600 opacity-50";
                      }
                    }

                    return (
                      <button
                        key={index}
                        onClick={() => handleAnswerClick(index)}
                        disabled={selectedOption !== null}
                        className={buttonClass}
                      >
                        <div className="flex justify-between items-center">
                          <span>{option}</span>
                          {selectedOption !== null && index === correctAnswers[currentQuestion] && <Check size={20} />}
                          {selectedOption === index && index !== correctAnswers[currentQuestion] && <X size={20} />}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {selectedOption !== null && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 p-4 bg-turbo-400/10 border border-turbo-400/20 rounded-xl text-turbo-400 text-sm"
                  >
                    💡 {questions[currentQuestion].explanation}
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

export default Quiz;