import React from 'react';
import { Star, Quote } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../LanguageContext';

const Testimonials: React.FC = () => {
  const { t } = useLanguage();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <section className="py-24 bg-zinc-950 border-t border-white/5 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-turbo-400/5 rounded-full blur-[100px] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
        >
            <h2 className="text-4xl font-black text-white mb-4">{t.testimonials.title}</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">{t.testimonials.subtitle}</p>
        </motion.div>

        <motion.div 
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
            {t.testimonials.reviews.map((review, index) => (
                <motion.div 
                    key={index} 
                    variants={item}
                    className="bg-zinc-900 border border-white/10 p-6 rounded-2xl relative group hover:border-turbo-400/30 transition-colors"
                >
                    <Quote className="absolute top-6 right-6 text-white/5 w-8 h-8 group-hover:text-turbo-400/10 transition-colors" />
                    
                    <div className="flex gap-1 mb-4">
                        {[...Array(5)].map((_, i) => (
                            <Star key={i} size={16} className="fill-turbo-400 text-turbo-400" />
                        ))}
                    </div>
                    
                    <p className="text-gray-300 mb-6 leading-relaxed italic relative z-10">
                        "{review.text}"
                    </p>
                    
                    <div className="flex items-center gap-3 mt-auto">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-turbo-400 to-yellow-600 flex items-center justify-center text-black font-bold text-sm">
                            {review.name.charAt(0)}
                        </div>
                        <span className="font-bold text-white text-sm">{review.name}</span>
                    </div>
                </motion.div>
            ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;