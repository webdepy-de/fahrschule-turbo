import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Globe } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const { language, setLanguage, t, isRTL } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: t.nav.start, href: '#home' },
    { name: t.nav.offer, href: '#offer' },
    { name: t.nav.pricing, href: '#pricing' },
    { name: t.nav.quiz, href: '#quiz' },
    { name: t.nav.gallery, href: '#gallery' },
    { name: t.nav.faq, href: '#faq' },
    { name: t.nav.contact, href: '#contact' },
  ];

  const languages = [
    { code: 'DE', label: 'Deutsch' },
    { code: 'EN', label: 'English' },
    { code: 'TR', label: 'Türkçe' },
    { code: 'AR', label: 'العربية' },
  ];

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-black/90 backdrop-blur-md border-b border-white/10 py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            {/* Logo ONLY, no text */}
            <img src="https://i.imgur.com/25kXdLL.png" alt="Fahrschule Turbo Logo" className="h-16 w-auto object-contain" />
          </div>
          
          <div className="hidden xl:block">
            <div className={`flex items-baseline space-x-6 ${isRTL ? 'space-x-reverse' : ''} mx-10`}>
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-gray-300 hover:text-turbo-400 px-2 py-2 rounded-md text-sm font-medium transition-colors duration-200"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-4">
            {/* Language Switcher */}
            <div className="relative">
              <button 
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1 text-gray-300 hover:text-white transition-colors"
              >
                <Globe size={18} />
                <span className="text-sm font-bold">{language}</span>
              </button>
              
              {langMenuOpen && (
                <div className={`absolute mt-2 w-32 bg-zinc-900 border border-white/10 rounded-lg shadow-xl py-1 z-50 ${isRTL ? 'left-0' : 'right-0'}`}>
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code as any);
                        setLangMenuOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-turbo-400"
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <a 
              href="tel:+4917670622756" 
              className="flex items-center gap-2 bg-turbo-400 hover:bg-turbo-500 text-black px-4 py-2 rounded-full font-bold transition-all text-sm shadow-[0_0_15px_rgba(250,204,21,0.3)]"
            >
              <Phone size={16} />
              <span>0176 7062 2756</span>
            </a>
          </div>

          <div className="-mr-2 flex md:hidden items-center gap-4">
            <button 
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="text-gray-300"
              >
                <Globe size={24} />
              </button>

            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-turbo-400 hover:bg-white/5 focus:outline-none"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-black/95 backdrop-blur-xl border-b border-white/10">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="text-gray-300 hover:text-turbo-400 block px-3 py-2 rounded-md text-base font-medium"
              >
                {link.name}
              </a>
            ))}
             <a 
              href="tel:+4917670622756"
              className="flex w-full items-center justify-center gap-2 bg-turbo-400 text-black px-3 py-3 mt-4 rounded-md font-bold"
            >
              <Phone size={18} /> {t.nav.call}
            </a>
          </div>
        </div>
      )}
      
      {/* Mobile Language Menu Overlay */}
      {langMenuOpen && (
         <div className="absolute top-16 right-4 w-32 bg-zinc-900 border border-white/10 rounded-lg shadow-xl py-1 z-50 md:hidden">
            {languages.map((lang) => (
              <button
                key={lang.code}
                onClick={() => {
                  setLanguage(lang.code as any);
                  setLangMenuOpen(false);
                }}
                className={`block w-full px-4 py-2 text-sm text-gray-300 hover:bg-white/10 hover:text-turbo-400 ${isRTL ? 'text-right' : 'text-left'}`}
              >
                {lang.label}
              </button>
            ))}
          </div>
      )}
    </nav>
  );
};

export default Navbar;