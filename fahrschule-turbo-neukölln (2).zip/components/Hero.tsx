import React from 'react';
import { ArrowRight, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../LanguageContext';

const Hero: React.FC = () => {
  const { t, isRTL } = useLanguage();

  return (
    <div id="home" className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://i.imgur.com/AN5lMMr.jpeg" 
          alt="Car Interior Dashboard" 
          className="w-full h-full object-cover"
        />
        {/* Overlays for readability and style */}
        <div className="absolute inset-0 bg-black/70"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center gap-2 mb-4"
          >
            <div className="flex bg-white/10 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
              <Star className="text-turbo-400 w-4 h-4 mr-2 fill-current" />
              <span className="text-xs font-semibold uppercase tracking-wider text-white">{t.hero.since}</span>
            </div>
            <div className="px-3 py-1 rounded-full border border-turbo-400/30 bg-turbo-400/10 text-turbo-400 text-xs font-bold uppercase tracking-wider">
              {t.hero.location}
            </div>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-black text-white tracking-tighter leading-none mb-6"
          >
            {t.hero.headline_prefix} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-turbo-400 to-yellow-600">
              {t.hero.headline_suffix}
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-gray-300 mb-8 max-w-xl leading-relaxed"
          >
            {t.hero.subheadline}
            <br />
            {t.hero.languages}
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <a 
              href="#offer" 
              className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-lg text-black bg-turbo-400 hover:bg-turbo-500 md:text-lg transition-all shadow-[0_0_20px_rgba(250,204,21,0.4)] hover:shadow-[0_0_30px_rgba(250,204,21,0.6)]"
            >
              {t.hero.btn_offer}
              <ArrowRight className={`w-5 h-5 ${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} />
            </a>
            <a 
              href="#contact" 
              className="inline-flex items-center justify-center px-8 py-4 border border-white/20 text-base font-bold rounded-lg text-white bg-white/5 hover:bg-white/10 backdrop-blur-sm md:text-lg transition-all"
            >
              {t.hero.btn_contact}
            </a>
          </motion.div>
        </div>
      </div>
      
      {/* Scrolling decorative element */}
      <div className="absolute bottom-0 w-full h-24 bg-gradient-to-t from-black to-transparent pointer-events-none"></div>
    </div>
  );
};

export default Hero;