import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../LanguageContext';

const Pricing: React.FC = () => {
  const { t } = useLanguage();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariant = {
    hidden: { opacity: 0, x: -20 },
    show: { opacity: 1, x: 0 }
  };

  return (
    <section id="pricing" className="py-24 bg-black relative">
       <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
         <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
         >
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">{t.pricing.title}</h2>
            <p className="text-gray-400">{t.pricing.subtitle}</p>
         </motion.div>

         <div className="glass-card rounded-2xl overflow-hidden border border-white/10">
            <div className="grid grid-cols-12 gap-4 bg-white/5 p-4 text-sm font-bold text-turbo-400 uppercase tracking-wider border-b border-white/10">
                <div className="col-span-6 md:col-span-6">{t.pricing.col_service}</div>
                <div className="col-span-3 md:col-span-3 text-right">{t.pricing.col_duration}</div>
                <div className="col-span-3 md:col-span-3 text-right">{t.pricing.col_price}</div>
            </div>
            
            <motion.div 
                variants={container}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: "-50px" }}
                className="divide-y divide-white/5"
            >
                {t.pricing.items.map((item, index) => (
                    <motion.div 
                        key={index} 
                        variants={itemVariant}
                        className="grid grid-cols-12 gap-4 p-4 md:p-6 hover:bg-white/5 transition-colors items-center group"
                    >
                        <div className="col-span-6 md:col-span-6 font-medium text-white group-hover:text-turbo-400 transition-colors">
                            {item.service}
                        </div>
                        <div className="col-span-3 md:col-span-3 text-right text-gray-400 font-mono text-sm md:text-base">
                            {item.duration}
                        </div>
                        <div className="col-span-3 md:col-span-3 text-right text-white font-bold font-mono text-base md:text-lg">
                            {item.price}
                        </div>
                    </motion.div>
                ))}
            </motion.div>
         </div>
       </div>
    </section>
  );
};

export default Pricing;