import React from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  content: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, content }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />
        
        {/* Content */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-zinc-900 border border-white/10 w-full max-w-2xl max-h-[80vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col relative z-10"
        >
          <div className="p-4 border-b border-white/10 flex justify-between items-center bg-zinc-800">
            <h3 className="text-xl font-bold text-white">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <X size={20} className="text-gray-400" />
            </button>
          </div>
          
          <div className="p-6 overflow-y-auto text-gray-300 space-y-4 text-sm leading-relaxed">
            {content}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

interface LegalModalsProps {
  imprintOpen: boolean;
  privacyOpen: boolean;
  closeAll: () => void;
}

export const LegalModals: React.FC<LegalModalsProps> = ({ imprintOpen, privacyOpen, closeAll }) => {
  
  const imprintContent = (
    <>
      <p><strong>Angaben gemäß § 5 TMG</strong></p>
      <p>
        Fahrschule Turbo<br />
        Inhaber: [Muster-Name, bitte einfügen]<br />
        Donaustraße 101<br />
        12043 Berlin
      </p>
      
      <p><strong>Kontakt</strong></p>
      <p>
        Telefon: 030 56821280<br />
        Mobil: 0176 70622756<br />
        E-Mail: info@fahrschuleturbo.de
      </p>
      
      <p><strong>Aufsichtsbehörde</strong></p>
      <p>
        Landesamt für Bürger- und Ordnungsangelegenheiten (LABO)<br />
        Puttkamerstr. 16 - 18<br />
        10958 Berlin
      </p>

      <p><strong>Umsatzsteuer-ID</strong></p>
      <p>Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz: [DE Muster-Nummer]</p>
      
      <p><strong>Hinweis</strong></p>
      <p>Dies ist eine Demo-Webseite. Die Angaben sind Platzhalter.</p>
    </>
  );

  const privacyContent = (
    <>
      <h4 className="text-white font-bold mb-2">1. Datenschutz auf einen Blick</h4>
      <p>
        <strong>Allgemeine Hinweise</strong><br/>
        Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen.
      </p>
      
      <h4 className="text-white font-bold mt-4 mb-2">2. Hosting</h4>
      <p>
        Wir hosten die Inhalte unserer Website bei einem externen Anbieter (Host). Die personenbezogenen Daten, die auf dieser Website erfasst werden, werden auf den Servern des Hosts gespeichert.
      </p>

      <h4 className="text-white font-bold mt-4 mb-2">3. Google Maps</h4>
      <p>
        Diese Seite nutzt den Kartendienst Google Maps. Anbieter ist die Google Ireland Limited ("Google"), Gordon House, Barrow Street, Dublin 4, Irland.
        Zur Nutzung der Funktionen von Google Maps ist es notwendig, Ihre IP-Adresse zu speichern. Diese Informationen werden in der Regel an einen Server von Google in den USA übertragen und dort gespeichert.
      </p>

      <h4 className="text-white font-bold mt-4 mb-2">4. Kontaktformular</h4>
      <p>
        Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre Angaben aus dem Anfrageformular inklusive der von Ihnen dort angegebenen Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert. Diese Daten geben wir nicht ohne Ihre Einwilligung weiter.
      </p>
    </>
  );

  return (
    <>
      {imprintOpen && <Modal isOpen={imprintOpen} onClose={closeAll} title="Impressum" content={imprintContent} />}
      {privacyOpen && <Modal isOpen={privacyOpen} onClose={closeAll} title="Datenschutzerklärung" content={privacyContent} />}
    </>
  );
};