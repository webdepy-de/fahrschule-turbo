import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../LanguageContext';
import { Cpu, ArrowRight } from 'lucide-react';

const Offer: React.FC = () => {
  const { t, isRTL } = useLanguage();

  return (
    <section id="offer" className="py-24 bg-black relative overflow-hidden scroll-mt-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 border-b border-white/10 pb-12 relative">
          <div className="max-w-2xl">
            <motion.h2 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-bold text-white tracking-tight mb-8"
            >
              {t.offer.title_prefix} <span className="text-turbo-400">{t.offer.title_highlight}</span>
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-xl text-gray-400 leading-relaxed"
            >
              {t.offer.description}
            </motion.p>
          </div>
          
          <div className="hidden md:flex absolute right-0 top-0 p-4 rounded-full border border-white/10">
            <Cpu className="text-gray-500 w-8 h-8" />
          </div>
        </div>

        {/* Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {t.offer.features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center text-sm font-mono text-gray-400 mb-6 group-hover:border-turbo-400 group-hover:text-turbo-400 transition-colors">
                {String(index + 1).padStart(2, '0')}
              </div>
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-turbo-400 transition-colors">
                {feature}
              </h3>
              <div className="h-0.5 w-12 bg-white/10 group-hover:bg-turbo-400 transition-colors mt-4"></div>
            </motion.div>
          ))}

          {/* Pricing Highlight as the final step */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.7 }}
            className="bg-zinc-900 border border-turbo-400/30 p-8 rounded-2xl relative overflow-hidden group hover:border-turbo-400 transition-colors"
          >
            <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-40 transition-opacity">
               <div className="w-20 h-20 bg-turbo-400 rounded-full blur-2xl"></div>
            </div>
            
            <div className="w-12 h-12 rounded-full bg-turbo-400 text-black flex items-center justify-center text-sm font-bold font-mono mb-6">
              08
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">
              {t.offer.price_label}
            </h3>
            <div className="flex items-baseline gap-2 mb-4">
               <span className="text-4xl font-black text-turbo-400">{t.offer.price_value}</span>
               <span className="text-sm text-gray-500 line-through">{t.offer.instead_of}</span>
            </div>
            
            {/* Link to Contact Section for Registration */}
            <a href="#contact" className="inline-flex items-center text-white font-bold hover:text-turbo-400 transition-colors">
              {t.offer.btn_signup} <ArrowRight className={`w-4 h-4 ${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} />
            </a>
          </motion.div>
        </div>

      </div>
    </section>
  );
};

export default Offer;