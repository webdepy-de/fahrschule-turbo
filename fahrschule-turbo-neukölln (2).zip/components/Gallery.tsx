import React, { useEffect, useRef } from 'react';
import { GalleryImage } from '../types';
import { Instagram } from 'lucide-react';
import { motion, useInView, useMotionValue, useSpring } from 'framer-motion';
import { useLanguage } from '../LanguageContext';

// Helper component for counting up numbers
const Counter = ({ value }: { value: number }) => {
  const ref = useRef<HTMLSpanElement>(null);
  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, { damping: 50, stiffness: 100 });
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (isInView) {
      motionValue.set(value);
    }
  }, [isInView, value, motionValue]);

  useEffect(() => {
    return springValue.on("change", (latest) => {
      if (ref.current) {
        ref.current.textContent = Math.floor(latest).toString();
      }
    });
  }, [springValue]);

  return <span ref={ref} />;
};

const Gallery: React.FC = () => {
  const { t } = useLanguage();

  const images: GalleryImage[] = [
    { url: "https://i.imgur.com/6jlaiy0.jpg", alt: "Happy Student 1" },
    { url: "https://i.imgur.com/ZL0Ptey.jpg", alt: "Happy Student 2" },
    { url: "https://i.imgur.com/FCZCbW0.jpg", alt: "Happy Student 3" },
    { url: "https://i.imgur.com/UTuPkI1.jpg", alt: "Happy Student 4" },
    { url: "https://i.imgur.com/Nco4yYz.jpg", alt: "Happy Student 5" },
    { url: "https://i.imgur.com/6WvQdb8.jpg", alt: "Happy Student 6" },
    { url: "https://i.imgur.com/7Glv8fp.jpg", alt: "Happy Student 7" },
    { url: "https://i.imgur.com/f6YUCvS.jpg", alt: "Happy Student 8" },
    { url: "https://i.imgur.com/p0NoHSf.jpg", alt: "Happy Student 9" },
    { url: "https://i.imgur.com/ss5BfGX.jpg", alt: "Happy Student 10" },
    { url: "https://i.imgur.com/EHeJBKv.jpg", alt: "Happy Student 11" },
    { url: "https://i.imgur.com/99EdJ1X.jpg", alt: "Happy Student 12" },
    { url: "https://i.imgur.com/dVs7QKc.jpg", alt: "Happy Student 13" },
  ];

  // Duplicate images for infinite seamless loop
  const marqueeImages = [...images, ...images];

  return (
    <section id="gallery" className="py-24 bg-black overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="flex flex-col md:flex-row justify-between items-end gap-6">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
                <h2 className="text-4xl md:text-6xl font-black text-white mb-2">{t.gallery.title}</h2>
                <p className="text-gray-400 text-lg">{t.gallery.subtitle}</p>
            </motion.div>
            
            <div className="flex gap-4 text-center">
                 <motion.div 
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className="bg-zinc-900 border border-white/10 px-6 py-4 rounded-xl min-w-[120px]"
                 >
                     <div className="text-3xl font-bold text-white flex justify-center items-center">
                        <Counter value={1461} />+
                     </div>
                     <span className="text-xs text-gray-500 uppercase tracking-wider">{t.gallery.followers}</span>
                 </motion.div>
                 <motion.div 
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                    className="bg-zinc-900 border border-white/10 px-6 py-4 rounded-xl min-w-[120px]"
                 >
                     <div className="text-3xl font-bold text-turbo-400 flex justify-center items-center">
                        <Counter value={55} />
                     </div>
                     <span className="text-xs text-gray-500 uppercase tracking-wider">{t.gallery.posts}</span>
                 </motion.div>
            </div>
        </div>
      </div>

      {/* Infinite Marquee */}
      <div className="relative w-full">
         {/* Gradients to fade edges */}
         <div className="absolute left-0 top-0 bottom-0 w-10 md:w-40 bg-gradient-to-r from-black via-black/80 to-transparent z-10 pointer-events-none"></div>
         <div className="absolute right-0 top-0 bottom-0 w-10 md:w-40 bg-gradient-to-l from-black via-black/80 to-transparent z-10 pointer-events-none"></div>

         <div className="flex w-max animate-marquee hover:[animation-play-state:paused]"> 
             {marqueeImages.map((img, idx) => (
                 <div 
                    key={idx} 
                    className="relative w-[200px] md:w-[280px] aspect-[4/5] mx-2 flex-shrink-0 rounded-xl overflow-hidden group transition-all duration-300 hover:scale-105 hover:z-20 border border-white/5 bg-zinc-900"
                 >
                     <img 
                        src={img.url} 
                        alt={img.alt} 
                        className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                        loading="lazy"
                     />
                     <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                        <span className="text-turbo-400 font-bold text-sm">{t.gallery.passed_badge} 🚗💨</span>
                     </div>
                 </div>
             ))}
         </div>
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="mt-16 flex justify-center"
      >
        {/* Fancy Instagram Button */}
        <a 
            href="https://www.instagram.com/fahrschule__turbo" 
            target="_blank" 
            rel="noreferrer" 
            className="flex items-center gap-4 bg-zinc-900/80 backdrop-blur-sm border border-white/10 px-8 py-5 rounded-2xl text-white hover:bg-white/5 transition-all group hover:scale-105 hover:shadow-[0_0_40px_rgba(220,39,67,0.3)] duration-300"
        >
            <div className="p-2 rounded-lg bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] text-white shadow-lg">
                <Instagram size={28} />
            </div>
            <div className="text-left">
                <span className="block text-xs text-gray-400 uppercase tracking-widest font-semibold mb-1">{t.gallery.insta_btn_small}</span>
                <span className="text-xl font-bold bg-gradient-to-r from-[#f09433] via-[#dc2743] to-[#bc1888] bg-clip-text text-transparent group-hover:opacity-90">
                    @fahrschule__turbo
                </span>
            </div>
        </a>
      </motion.div>
    </section>
  );
};

export default Gallery;