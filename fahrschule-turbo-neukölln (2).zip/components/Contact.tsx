import React, { useState } from 'react';
import { MapPin, Phone, Mail, Instagram, MessageCircle, CheckCircle, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../LanguageContext';

const Contact: React.FC = () => {
  const { t } = useLanguage();
  const [formState, setFormState] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('submitting');
    
    // Simulate network request
    setTimeout(() => {
      setFormState('success');
      // Reset after showing success message
      setTimeout(() => {
        setFormState('idle');
        // Reset form fields logic would go here
        (e.target as HTMLFormElement).reset();
      }, 3000);
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-black relative overflow-hidden scroll-mt-32">
      {/* Background decoration */}
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-turbo-400/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-black text-white mb-8">{t.contact.title}</h2>
            
            <div className="space-y-8 mb-10">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-zinc-900 rounded-lg border border-white/10 text-turbo-400">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">{t.contact.address_title}</h3>
                  <p className="text-gray-400">Donaustraße 101<br/>12043 Berlin Neukölln</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 bg-zinc-900 rounded-lg border border-white/10 text-turbo-400">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">{t.contact.phone_title}</h3>
                  <p className="text-gray-400 flex flex-col gap-1">
                    <a href="tel:+493056821280" className="hover:text-white transition-colors">030 56821280</a>
                    <a href="tel:+4917670622756" className="hover:text-white transition-colors">0176 70622756</a>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 bg-zinc-900 rounded-lg border border-white/10 text-turbo-400">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">{t.contact.email_title}</h3>
                  <a href="mailto:info@fahrschuleturbo.de" className="text-gray-400 hover:text-white transition-colors">info@fahrschuleturbo.de</a>
                </div>
              </div>

              <div className="flex gap-4">
                 {/* Simple Instagram Button - becomes colorful on hover */}
                 <a 
                    href="https://www.instagram.com/fahrschule__turbo" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="p-4 rounded-xl bg-zinc-900 border border-white/10 text-white transition-all duration-300 hover:bg-gradient-to-tr hover:from-[#f09433] hover:via-[#dc2743] hover:to-[#bc1888] hover:border-transparent hover:-translate-y-1 shadow-lg hover:shadow-pink-900/30"
                 >
                    <Instagram size={28} />
                 </a>
                 
                 {/* Simple WhatsApp Button - becomes green on hover */}
                 <a 
                    href="https://wa.me/4917670622756" 
                    target="_blank" 
                    rel="noreferrer" 
                    className="p-4 rounded-xl bg-zinc-900 border border-white/10 text-white transition-all duration-300 hover:bg-[#25D366] hover:border-transparent hover:-translate-y-1 shadow-lg hover:shadow-green-900/30"
                 >
                    <MessageCircle size={28} />
                 </a>
              </div>
            </div>

            {/* Embedded Map */}
            <div className="w-full h-64 rounded-2xl overflow-hidden border border-white/10 grayscale hover:grayscale-0 transition-all duration-500">
                 <iframe 
                    src="https://maps.google.com/maps?q=Donaustra%C3%9Fe+101,+12043+Berlin&t=&z=15&ie=UTF8&iwloc=&output=embed" 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen 
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Fahrschule Turbo Location"
                ></iframe>
            </div>

          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="glass-card p-8 rounded-3xl border border-white/10 h-fit relative overflow-hidden"
          >
             <AnimatePresence mode="wait">
                {formState === 'success' ? (
                   <motion.div 
                      key="success"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900/95 backdrop-blur-sm z-20 text-center p-6"
                   >
                      <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                      <h3 className="text-2xl font-bold text-white mb-2">Nachricht gesendet!</h3>
                      <p className="text-gray-400">Wir melden uns so schnell wie möglich bei dir.</p>
                   </motion.div>
                ) : null}
             </AnimatePresence>

            <h3 className="text-2xl font-bold text-white mb-6">{t.contact.form_title}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">{t.contact.label_name}</label>
                <input type="text" className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-turbo-400 transition-colors" placeholder={t.contact.placeholder_name} required />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">{t.contact.label_phone}</label>
                <input type="tel" className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-turbo-400 transition-colors" placeholder={t.contact.placeholder_phone} required />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">{t.contact.label_interest}</label>
                <select className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-turbo-400 transition-colors appearance-none cursor-pointer">
                    <option value="auto">{t.contact.option_auto}</option>
                    <option value="motorrad">{t.contact.option_moto}</option>
                    <option value="buerger">{t.contact.option_citizen}</option>
                    <option value="sonstiges">{t.contact.option_other}</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-1">{t.contact.label_msg}</label>
                <textarea rows={4} className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-turbo-400 transition-colors" placeholder={t.contact.placeholder_msg}></textarea>
              </div>
              
              <button 
                type="submit" 
                disabled={formState === 'submitting'}
                className="w-full bg-turbo-400 text-black font-bold py-3 rounded-lg hover:bg-turbo-500 transition-all mt-2 text-lg hover:shadow-[0_0_20px_rgba(250,204,21,0.4)] transform hover:scale-[1.02] flex justify-center items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {formState === 'submitting' ? (
                   <>
                      <Loader2 className="w-5 h-5 animate-spin" /> Senden...
                   </>
                ) : (
                   t.contact.btn_submit
                )}
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Contact;