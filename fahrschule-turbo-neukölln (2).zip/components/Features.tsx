import React from 'react';
import { Globe2, Car, MapPin, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../LanguageContext';

const Features: React.FC = () => {
  const { t } = useLanguage();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 50 } }
  };

  return (
    <section className="py-16 bg-zinc-950 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          
          <motion.div variants={item} className="p-6 rounded-2xl bg-zinc-900/50 border border-white/5 hover:border-turbo-400/50 transition-colors group hover:-translate-y-2 duration-300">
            <Globe2 className="w-10 h-10 text-turbo-400 mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-2">{t.features.lang_title}</h3>
            <p className="text-gray-400">
              {t.features.lang_desc}
            </p>
          </motion.div>

          <motion.div variants={item} className="p-6 rounded-2xl bg-zinc-900/50 border border-white/5 hover:border-turbo-400/50 transition-colors group hover:-translate-y-2 duration-300">
            <Car className="w-10 h-10 text-turbo-400 mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-2">{t.features.fleet_title}</h3>
            <p className="text-gray-400">
              {t.features.fleet_desc}
            </p>
          </motion.div>

          <motion.div variants={item} className="p-6 rounded-2xl bg-zinc-900/50 border border-white/5 hover:border-turbo-400/50 transition-colors group hover:-translate-y-2 duration-300">
            <MapPin className="w-10 h-10 text-turbo-400 mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-2">{t.features.central_title}</h3>
            <p className="text-gray-400">
              {t.features.central_desc}
            </p>
          </motion.div>

          <motion.div variants={item} className="p-6 rounded-2xl bg-zinc-900/50 border border-white/5 hover:border-turbo-400/50 transition-colors group hover:-translate-y-2 duration-300">
            <Clock className="w-10 h-10 text-turbo-400 mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-2">{t.features.hours_title}</h3>
            <p className="text-gray-400">
              {t.features.hours_desc}
            </p>
          </motion.div>

        </motion.div>
      </div>
    </section>
  );
};

export default Features;